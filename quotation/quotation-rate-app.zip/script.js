// reliable-jewellery-rate-convention/quotation-rate-app/script.js

document.addEventListener('DOMContentLoaded', () => {

    // --- State ---
    const state = {
        usd: 0,
        purity: 0,
        omsRate: 31.1,
        dirhamRate: 3.67, // Fixed default for verification
        baseRate: 0, // Calculated Section 1

        // Table Values
        goldWeight: 0,
        goldCost: 0,

        diamondWeight: 0, // Input only
        diamondCost: 0,
        stoneCost: 0,
        otherCost: 0,
        makingCost: 0,

        totalCost: 0,

        // Pricing
        marginPercent: 0,
        finalPrice: 0
    };

    // --- Elements ---

    // Section 1
    const usdInput = document.getElementById('usd-input');
    const purityInput = document.getElementById('purity-input');
    const baseRateDisplay = document.getElementById('base-rate-result');
    const omsRateInput = document.getElementById('oms-rate'); // Hidden
    const dirhamRateInput = document.getElementById('dirham-rate'); // Hidden
    // const liveStatusDot = document.getElementById('live-dot'); // Removed live logic for strict verification
    // const rateStatusText = document.getElementById('rate-status');

    // Section 2
    const goldWeightInput = document.getElementById('gold-weight');
    const goldCostDisplay = document.getElementById('gold-cost');

    // Diamond Col 2 & 3
    const diamondWeightInput = document.getElementById('diamond-weight');
    const diamondCostInput = document.getElementById('diamond-cost');

    const stoneCostInput = document.getElementById('stone-cost');
    const otherCostInput = document.getElementById('other-cost');
    const makingCostInput = document.getElementById('making-cost');

    const totalCostDisplay = document.getElementById('total-cost-display');

    // Section 3
    // Section 3
    const price15 = document.getElementById('price-15');
    const price20 = document.getElementById('price-20');
    const price25 = document.getElementById('price-25');
    const price30 = document.getElementById('price-30');
    const price35 = document.getElementById('price-35');
    const priceCustom = document.getElementById('price-custom');
    const customMarginInput = document.getElementById('custom-margin-input');

    // Section 4
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const imagePreview = document.getElementById('image-preview');
    const uploadPlaceholder = document.getElementById('upload-placeholder');
    const removeImageBtn = document.getElementById('remove-image-btn');

    // --- Logic ---

    // 1. Fetch Live AED Rate (Disabled for Strict Verification Compliance)
    /* 
    async function fetchRate() {
        ...
    } 
    */

    // 2. Calculations
    function calculateAll() {
        // --- Section 1: Rate Converter ---
        state.usd = parseFloat(usdInput.value) || 0;
        state.purity = parseFloat(purityInput.value) || 0;
        state.omsRate = parseFloat(omsRateInput.value) || 31.1;
        state.dirhamRate = parseFloat(dirhamRateInput.value) || 3.67;

        // Formula: Result = (USD / Ounce Rate) * Dirham * Purity
        // Requirement: Absolutely no rounding during calculation, show exactly 4 decimals.
        if (state.omsRate > 0) {
            state.baseRate = (state.usd / state.omsRate) * state.dirhamRate * state.purity;
        } else {
            state.baseRate = 0;
        }

        // Display: Exactly 4 decimal places
        baseRateDisplay.textContent = state.baseRate.toFixed(4);

        // --- Section 2: Table ---
        state.goldWeight = parseFloat(goldWeightInput.value) || 0;

        // Gold Cost = Base Rate * Gold Weight
        // Note: Base Rate used here is the full precision value (state.baseRate), not the rounded display.
        state.goldCost = state.baseRate * state.goldWeight;
        goldCostDisplay.textContent = state.goldCost.toFixed(2);

        // Other Costs
        state.diamondWeight = parseFloat(diamondWeightInput.value) || 0; // Just for record
        state.diamondCost = parseFloat(diamondCostInput.value) || 0;
        state.stoneCost = parseFloat(stoneCostInput.value) || 0;
        state.otherCost = parseFloat(otherCostInput.value) || 0;
        state.makingCost = parseFloat(makingCostInput.value) || 0;

        // Total Cost
        state.totalCost = state.goldCost + state.diamondCost + state.stoneCost + state.otherCost + state.makingCost;
        totalCostDisplay.textContent = state.totalCost.toFixed(2);

        // --- Section 3: Pricing Table ---
        // Formula: Final Price = (Total Cost / (100 - Margin)) * 100

        updatePriceRow(price15, 15);
        updatePriceRow(price20, 20);
        updatePriceRow(price25, 25);
        updatePriceRow(price30, 30);
        updatePriceRow(price35, 35);

        // Custom
        const customInputStr = customMarginInput.value;
        if (customInputStr === '' || customInputStr === null) {
            priceCustom.textContent = '';
        } else {
            const customVal = parseFloat(customInputStr) || 0;
            updatePriceRow(priceCustom, customVal);
        }
    }

    function updatePriceRow(element, margin) {
        let final = 0;
        if (state.totalCost > 0) {
            if (margin >= 0 && margin < 100) {
                final = (state.totalCost / (100 - margin)) * 100;
            } else {
                final = state.totalCost;
            }
        }
        element.textContent = final.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    // --- Event Listeners ---

    // Inputs (Added diamondWeightInput)
    [usdInput, purityInput, goldWeightInput, diamondWeightInput, diamondCostInput, stoneCostInput, otherCostInput, makingCostInput, customMarginInput].forEach(input => {
        input.addEventListener('input', calculateAll);
    });

    // Image Upload
    dropZone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleFileSelect);

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'var(--accent-color)';
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'var(--border-color)';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.style.borderColor = 'var(--border-color)';
        if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files);
    });

    function handleFileSelect(e) {
        if (e.target.files.length) handleFiles(e.target.files);
    }

    function handleFiles(files) {
        const file = files[0];
        if (file.type.startsWith('image/')) {
            const reader = new FileReader();
            reader.onload = (e) => {
                imagePreview.src = e.target.result;
                imagePreview.classList.remove('hidden');
                uploadPlaceholder.classList.add('hidden');
                removeImageBtn.classList.remove('hidden');
            };
            reader.readAsDataURL(file);
        }
    }

    // Actions
    const saveBtn = document.getElementById('save-btn');
    const shareBtn = document.getElementById('share-btn');
    const historySection = document.getElementById('history-section');
    const historyList = document.getElementById('history-list');

    // Share
    const shareContainer = document.getElementById('share-export-container');
    const shareTime = document.getElementById('share-time');

    // --- History State ---
    let history = JSON.parse(localStorage.getItem('quotation_history')) || [];

    function saveHistory() {
        const record = {
            id: Date.now(),
            time: new Date().toLocaleString(),
            data: { ...state } // Clone state
        };

        history.unshift(record);
        if (history.length > 10) history.pop(); // Max 10

        localStorage.setItem('quotation_history', JSON.stringify(history));
        renderHistory();
    }

    function renderHistory() {
        historyList.innerHTML = '';
        if (history.length === 0) {
            historySection.style.display = 'none';
            return;
        }

        historySection.style.display = 'block';
        history.forEach(item => {
            const div = document.createElement('div');
            div.className = 'history-item';
            div.innerHTML = `
                <div class="history-info">
                    <strong>AED ${item.data.finalPrice.toFixed(2)}</strong>
                    <span>${item.time}</span>
                </div>
                <button class="view-btn" data-id="${item.id}">View</button>
            `;

            div.querySelector('.view-btn').addEventListener('click', () => loadHistory(item.id));
            historyList.appendChild(div);
        });
    }

    function loadHistory(id) {
        const record = history.find(i => i.id === id);
        if (!record) return;

        const d = record.data;

        // Restore Inputs
        usdInput.value = d.usd || '';
        purityInput.value = d.purity || '';

        goldWeightInput.value = d.goldWeight || '';
        diamondWeightInput.value = d.diamondWeight || '';
        diamondCostInput.value = d.diamondCost || '';
        stoneCostInput.value = d.stoneCost || '';
        otherCostInput.value = d.otherCost || '';
        makingCostInput.value = d.makingCost || '';

        customMarginInput.value = d.marginPercent || '';

        // Trigger Calc
        calculateAll();

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // --- Share Logic ---
    // --- Share Logic ---
    async function shareResult() {
        console.log("Share button clicked");
        const shareBtnIcon = shareBtn.querySelector('i');
        const originalIcon = shareBtnIcon.className;

        try {
            // Feedback
            shareBtnIcon.className = "fa-solid fa-spinner fa-spin";
            shareBtn.childNodes[1].textContent = " Generating...";

            // 1. Prepare Data & Time
            const date = new Date();
            const dateStr = date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' }).replace(/\//g, '-');
            const timeStr = date.toLocaleTimeString('en-US', { timeZone: "Asia/Dubai", hour: '2-digit', minute: '2-digit', hour12: true });
            document.getElementById('share-time').textContent = `${dateStr} | ${timeStr}`;

            // 2. Populate Rate Conversion
            document.getElementById('ex-usd').textContent = usdInput.value || "-";
            document.getElementById('ex-purity').textContent = purityInput.value || "-";
            document.getElementById('ex-rate').textContent = baseRateDisplay.textContent;

            // 3. Populate Cost Analysis
            document.getElementById('ex-gold-wt').textContent = goldWeightInput.value || "-";
            document.getElementById('ex-gold-cost').textContent = goldCostDisplay.textContent;

            document.getElementById('ex-diamond-wt').textContent = diamondWeightInput.value || "-";
            document.getElementById('ex-diamond-cost').textContent = diamondCostInput.value || "-";

            document.getElementById('ex-stone-cost').textContent = stoneCostInput.value || "-";
            document.getElementById('ex-other-cost').textContent = otherCostInput.value || "-";
            document.getElementById('ex-making-cost').textContent = makingCostInput.value || "-";

            document.getElementById('ex-total-cost').textContent = totalCostDisplay.textContent;

            // 4. Populate Profit Table
            const profitBody = document.getElementById('ex-profit-body');
            profitBody.innerHTML = '';

            const createProfitRow = (margin, priceElId) => {
                const tr = document.createElement('tr');
                const pEl = document.getElementById(priceElId);
                const price = pEl ? pEl.textContent : "0.00";
                tr.innerHTML = `<td>${margin}%</td><td>${price}</td>`;
                profitBody.appendChild(tr);
            };

            createProfitRow(15, 'price-15');
            createProfitRow(20, 'price-20');
            createProfitRow(25, 'price-25');
            createProfitRow(30, 'price-30');
            createProfitRow(35, 'price-35');

            if (customMarginInput.value) {
                const tr = document.createElement('tr');
                const price = document.getElementById('price-custom').textContent;
                tr.innerHTML = `<td>${customMarginInput.value}% (Custom)</td><td>${price}</td>`;
                profitBody.appendChild(tr);
            }

            // 5. Image
            const imgContent = document.getElementById('image-preview');
            const shareImgContainer = document.getElementById('share-image-container');
            shareImgContainer.innerHTML = '';
            if (imgContent && !imgContent.classList.contains('hidden') && imgContent.src) {
                const imgClone = imgContent.cloneNode(true);
                shareImgContainer.appendChild(imgClone);
            } else {
                shareImgContainer.innerHTML = '<span style="color:#ccc; font-size:0.8rem;">No Image</span>';
                shareImgContainer.style.display = 'flex';
                shareImgContainer.style.alignItems = 'center';
                shareImgContainer.style.justifyContent = 'center';
            }

            // 6. Notes
            const noteInput = document.getElementById('note-input');
            const noteOutput = document.getElementById('ex-note-content');
            if (noteInput && noteInput.value.trim()) {
                noteOutput.textContent = noteInput.value;
                noteOutput.style.display = 'block';
            } else {
                noteOutput.textContent = 'No notes provided.';
                noteOutput.style.color = '#777';
                noteOutput.style.padding = '5px';
            }

            // 7. Capture
            const container = document.getElementById('share-export-container');
            container.style.left = "0"; // Valid coordinate for capture

            await new Promise(resolve => setTimeout(resolve, 500));

            const canvas = await html2canvas(container, {
                scale: 2,
                useCORS: true,
                backgroundColor: '#ffffff', // Excel background is white/light
                logging: false,
                width: 800, // Compact width
                windowWidth: 800
            });

            container.style.left = "-9999px"; // Hide again

            // 7. Download
            const link = document.createElement('a');
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            link.download = `Quotation_${timestamp}.jpg`;
            link.href = canvas.toDataURL('image/jpeg', 0.95);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            // Restore Button
            shareBtnIcon.className = originalIcon;
            shareBtn.childNodes[1].textContent = " Download Result (JPG)";

        } catch (err) {
            console.error("Export Error:", err);
            alert('Failed to generate image. Please check console.');
            shareBtnIcon.className = originalIcon;
            shareBtn.childNodes[1].textContent = " Download Result (JPG)";
        }
    }

    saveBtn.addEventListener('click', saveHistory);
    shareBtn.addEventListener('click', shareResult);

    // Init History
    renderHistory();

    // --- Init ---
    // fetchRate(); // Disabled for verification
    const rateStatus = document.getElementById('rate-status');
    if (rateStatus) rateStatus.textContent = "AED: 3.6700 (Fixed)";

    const liveDot = document.getElementById('live-dot');
    if (liveDot) liveDot.style.backgroundColor = 'var(--text-secondary)';

    // Initial Calc
    calculateAll();
});
